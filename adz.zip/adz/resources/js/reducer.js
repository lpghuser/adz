import { combineReducers } from "redux";
import plainsReducer from "./components/features/plains/plainSlice";

const rootReducer = combineReducers({
    plains: plainsReducer
});

export default rootReducer;
