import React, { useState } from 'react';
import Header from '../components/UI/Header/Header';
import Footer from '../components/UI/Footer/Footer';
import CheckPlainDetail from "../components/features/plains/CheckPlainPage/CheckPlainPage";

function App() {
    return (
        <div className="container container-wrapper">
                <Header/>
                <CheckPlainDetail/>
                <Footer/>
        </div>
    );
}

export default App;

