import React from 'react';
import './Footer.scss'

const logoUrl = 'https://admin.anzbds.com//userfiles/images/webconfig/id_5/15951515085.png';
const Footer = () => {
    return (
        <footer className="footer footer_fix_bottom">
            <div className="container footer-mask">
                <div className="container footer-contant">
                    <div className="row">
                        <div className="col-md-6">
                            <a href="#" className="brand">
                                <img src={logoUrl} style={{width: '50px', height: '50px'}} alt=""/> <strong
                                    style={{color: '#dc3545'}}>CHẠM LIỀN TAY - CÓ NGAY BẤT ĐỘNG SẢN</strong>
                            </a>
                            <address className="ts-text-color-light text-muted " style={{marginTop: 0.5 + 'rem'}}>
                                <strong className="text-white">Head office: </strong> <span
                                style={{color: '#fefefe', fontSize: '12px'}}>41 đường 20, Phường Hiệp Bình Chánh, Quận Thủ Đức, Tp. Hồ Chí Minh, Việt Nam</span>
                                <br/>
                                    <strong className="text-white">Email: </strong>
                                    <a href="mailto:{{ $email }}" className="btn-link"
                                       style={{fontSize: '12px'}}>info@anzbds.com</a>
                                    <br/>
                                        <strong className="text-white">Hotline: </strong>
                                        <a href="tel:{{ $phone }}" className="btn-link"
                                           style={{fontSize: '12px'}}> 0917 99 86 88</a></address>
                            <a href="{{ $urlClient }}lien-he" target="_blank" className="btn custom-btn-outline mb-4">Liên
                                hệ với chúng tôi</a>
                        </div>

                        <div className="col-md-2">
                            <h4 className="text-white">VỀ ANZBDS</h4>
                            <nav className="nav flex-row flex-md-column mb-4" style={{display: 'inline-grid'}}>
                                <a href="{{ $urlClient }}lien-he" target="_blank" className="nav-link mb-3">Liên hệ</a>
                                <a href="{{ $urlClient }}gioi-thieu" target="_blank" className="nav-link mb-3">Giới
                                    thiệu</a>
                                <a href="{{ $urlClient }}tuyen-dung" target="_blank" className="nav-link mb-3">Tuyển
                                    dụng</a>
                            </nav>
                        </div>

                        <div className="col-md-2">
                            <h4 className="text-white">DỊCH VỤ</h4>
                            <nav className="nav flex-row flex-md-column mb-4" style={{display: 'inline-grid'}}>
                                <a href="{{ $urlClient }}mua/bat-dong-san" target="_blank" className="nav-link mb-3">Mua
                                    bán</a>
                                <a href="{{ $urlClient }}thue/bat-dong-san" target="_blank" className="nav-link mb-3">Cho
                                    thuê</a>
                                <a href="/ky-gui-bds/submit" className="nav-link mb-3">Ký gửi BĐS</a>
                            </nav>
                        </div>

                        <div className="col-md-2" style={{display: 'inline-grid'}}>
                            <a href="https://apps.apple.com/vn/app/anzbds/id1519578125?l=vi"
                               className="nav-link icon-device"><img src="/assets/img/app-store-badge-vi.png"
                                                                     style={{width: '100%', height: '40px', padding: '0 15px'}}
                                                                     alt=""/></a><br/>
                            <a href="https://play.google.com/store/apps/details?id=com.ftcjsc.anzbds"
                               className="nav-link icon-device"><img src="/assets/img/google-play-badge-vi.png"
                                                                              style={{width: '100%', height: '40px', padding: '0 15px'}}
                                                                              alt=""/></a>
                        </div>
                    </div>
                </div>
                <div className="footer-bottom">
                    <div className="container text-center">
                        <div className="ts-copyright"><span className="">2020 © <a href="https://anzbds.com/"
                                                                                   className="primary_color;">ANZBDS</a> - All Rights Reserved </span>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    )
};

export default Footer;
