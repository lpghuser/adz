import React from 'react';
import './Header.scss'

const logoUrl = 'https://admin.anzbds.com//userfiles/images/webconfig/id_5/15951515085.png';
const Header = () => {
    return (
        <header className="header top-bar-fixed">
            <div className="top-box  ">
                <div className="container">
                    <div className="top-bar color-primary">
                        <div className="container clearfix">
                            <div className="pull-left">
                                <ul className="login-menu clearfix">
                                    <li><i className="fa fa-phone-square"></i> 0917 99 86 88</li>
                                    <li><i className="fa fa-envelope"></i> info@anzbds.com</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <section className="header-inner">
                        <div className="container">
                            <div className="logo pull-left pull-sm-up col-sm-6 col-xs-12  text-left">
                                <a href="/">
                                    <img src="{{ $logo }}" style={{width: '50px', height: '50px'}} alt=""
                                         className="mini-logo"/>
                                </a>
                            </div>
                            <div className="pull-left menu">
                                <div className="box-navigaion clearfix">
                                    <div className="navbar-header">
                                        <button type="button" className="navbar-toggle" data-toggle="collapse"
                                                data-target="#main-menu">
                                            <span className="sr-only">Toggle navigation</span>
                                            <span className="icon-bar"></span>
                                            <span className="icon-bar"></span>
                                            <span className="icon-bar"></span>
                                        </button>
                                    </div>
                                </div>
                                <nav className="navbar text-color-primary">
                                    <div className="text-right">
                                        <button className="navbar-toggler hidden" type="button" data-toggle="collapse"
                                                data-target="#main-menu">
                                            &#9776;
                                        </button>
                                    </div>
                                    <div className="collapse navbar-collapse" id="main-menu">
                                        <ul className="nav navbar-nav clearfix">
                                            <li className="nav-item">
                                                <a href="/" style={{padding: '10px 0 0 0', marginRight: 1.5 + 'rem'}}>
                                                    <img src={logoUrl} style={{width: '50px', height: '50px'}} alt=''/>
                                                </a>
                                            </li>

                                            <li className="nav-item">
                                                <a className="nav-link {{ strpos(Request::url(), '/') !== false  ? 'active' : '' }}"
                                                   href="/" role="button">
                                                    Trang kiểm tra quy hoạch
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <div className="top-box-mask"></div>
        </header>
    )
};

export default Header;
