import React, { useState } from "react";
import { listCitis } from "../../../data/database";
import './SearchForm.scss';

const SearchForm = () => {
    const [ {city, district, ward, lotOfLand, mapSheet }, setData] = useState({
        city: "TP. Hồ Chí Minh",
        district: "Quận 1",
        ward: "Bến Nghé",
        lotOfLand: null,
        mapSheet: null
    });

    const citis = listCitis.map((c) => (
        <option key={c.id} value={c.label}>{c.label}</option>
    ));

    const districts = listCitis.find(c => c.label === city) ?.listDistricts.map((d) => (
        <option key={d.id} value={d.label}>{d.label}</option>
    ));

    const wards = listCitis.find(c => c.label === city)?.listDistricts.find(d => d.label === district)?.listWards.map((w) => (
        <option key={w.id} value={w.label}>{w.label}</option>
    ));

    const handleCityChange = (event) => {
        event.persist(); //Read Event Pooling
        setData(data => ({...data, city: event.target.value}));
    };

    const handleDistrictChange = (event) => {
        event.persist();
        setData(data => ({...data, district: event.target.value}));
    };

    const handleWardChange = (event) => {
        event.persist();
        setData(data => ({...data, ward: event.target.value}));
    };

    const handleLotofLandChange = (event) => {
        event.persist();
        setData(data => ({...data, lotOfLand: event.target.value}));
    };

    const handleMapSheetChange = (event) => {
        event.persist();
        setData(data => ({...data, mapSheet: event.target.value}));
    };

    function handleSubmit(e) {
        const data = {
            city,
            district,
            ward,
            lotOfLand,
            mapSheet
        }
        alert(JSON.stringify(data));
        e.preventDefault();
    };
    return (
        <form className="form-wrapper" onSubmit={handleSubmit}>
            <div className="form-content">
                <select className="form-item" value={city} onChange={handleCityChange}>
                    {citis}
                </select>
                <select className="form-item" value={district} onChange={handleDistrictChange}>
                    {districts}
                </select>
                <select className="form-item" value={ward} onChange={handleWardChange}>
                    {wards}
                </select>
                <div className="flex-box">
                    <input type="number" value={lotOfLand || ''} className="form-item" placeholder="Số tờ" onChange={handleLotofLandChange}/>
                    <input type="number" value={mapSheet || ''} className="form-item" placeholder="Số thửa" onChange={handleMapSheetChange}/>
                </div>
            </div>
            {/*<ImageUploadTool/>*/}
            <input type="submit" className="btn-submit" value="Tìm Kiếm"/>
        </form>
    )
};

export default SearchForm;
