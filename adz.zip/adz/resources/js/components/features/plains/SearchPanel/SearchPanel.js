import React, {useEffect, useState} from 'react';
import SearchForm from "../../searchForm/SearchForm";
import './SearchPanel.scss'

const SearchPanel = () => {
    const [ isShow, togglePanel ] = useState(true);
    const handleClick = (e) => {
        togglePanel(!isShow);
    }
    return (
        <div className={`search-panel-wrapper ${isShow ? "expand" : "collapse"}`}>
            <div className="search-panel">
                <div className="btn-toggle">
                    <button onClick={handleClick}>&#8702;</button>
                </div>
                <div className="panel-content">
                    <h3>Tìm kiếm</h3>
                    <SearchForm/>
                    <div id="result"></div>
                </div>
            </div>
        </div>
    )
}
export default SearchPanel;
