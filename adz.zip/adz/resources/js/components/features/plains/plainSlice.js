import { createSelector }  from "reselect";
import { fetchPlainsList } from "../../../apis/checkPlain"

const initialPlainState = {
    plainsData: []
};

export default function plainsReducer( state = initialPlainState, action) {
    switch (action.type) {
        case 'plains/plainsLoading': {
            return {
                ...state,
                status: 'loading'
            }
        }
        case 'plains/plainsLoaded': {
            return {
                ...state,
                status: 'idle',
                plainsData: action.payload
            }
        }
        case 'plains/plainsPageChange': {
            return {
                ...state,
                currentPage: action.payload
            }
        }
        default:
            return state;
    }
};

export const plainsLoading =() => ({ type: 'plains/plainsLoading'})
export const plainsLoaded = plains =>({ type: 'plains/plainsLoaded', payload: plains});
export const plainsPageChange = pageNum => ({ type: 'plains/plainsPageChange', payload: pageNum});
// export const fetchPlains = (pageNum = 1) => async dispatch => {
//     dispatch(plainsLoading());
//     const urls = ['http://anzbds.local/index', 'http://anzbds.local/index/?page=2', 'http://anzbds.local/index/?page=3', 'http://anzbds.local/index/?page=4']
//     fetchPlainsList(urls).then(responsePlainsData => {
//         //console.log('plains: ', responsePlainsData)
//         dispatch(plainsLoaded(responsePlainsData));
//     });
// };
