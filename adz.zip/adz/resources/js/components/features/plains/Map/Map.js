import React, { useEffect } from "react";
import L from "leaflet";
import { listFeatures } from '../../../../data/database';
import { fetchPlainsList } from '../../../../apis/checkPlain';
import './Map.scss';


const mapStyle = {
    width: "100%",
    height: "100%",
};
const getColor = (d) => {
    return  d > 1000 ? "#800026" :
            d > 500 ? "#BD0026" :
            d > 200 ? "#E31A1C" :
            d > 100 ? "#FC4E2A" :
            d > 50 ? "#CD853F" :
            d > 20 ? "#FEB24C" :
            d > 10 ? "#FED976" :
                    "#FFEDA0";
}

const style = (feature) => {
    return ({
        fillColor: getColor(feature.properties.density),
        weight: 1, //weight of bound line
        opacity: 1, // opacity of bound line
        color: '#808080', // color of bound line
        dashArray: '',
        fillOpacity: 0.3
    });
}

const coordsToLatLng = (coords) => {
        return new L.LatLng(coords[0], coords[1], coords[2]);
}

const Map = () => {
    useEffect(() => {
        // call API here. check routes/web.php, Http/Controllers/HomeController.php
        // const url = ['http://anzbds.local/index', 'http://anzbds.local/index?page=2', 'http://anzbds.local/index?page=3', 'http://anzbds.local/index?page=4'];
        // fetchPlainsList(url).then(d => console.log('gigi', d));
        const map = L.map('map').setView([10.768241, 106.6524723], 14);
        map.invalidateSize();
        L.tileLayer("https://api.mapbox.com/styles/v1/mapbox/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoiZmxvcnZhbmRla2VyY2tob3ZlIiwiYSI6ImNqdGZyMmtrejAxYWw0M3A2OGtwdTMxNWEifQ.5U-KSDZfyKNC_Z74fEWj6g",
            {
            id: "streets-v11",
            attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://mapbox.com">Mapbox</a>',
            tileSize: 512,
            zoomOffset: -1,
            maxZoom: 20
            }).addTo(map);

        let geojson = L.geoJson(listFeatures, {coordsToLatLng: coordsToLatLng, style: style});
        geojson.addTo(map);

        const updateInfo = (props) => {
            const featureData = '<b>' + props.name + '</b><br />' + props.density + ' people / mi<sup>2</sup>';
            jQuery('#result').html(featureData);
        };
        //info.addTo(map);


        const highlightFeature = (e) => {
            const layer = e.target;

            layer.setStyle({
                fillColor: '#FA8072',
                weight: 2,
                color: '#DC143C',
                dashArray: '',
                fillOpacity: 0.4
            });
            layer.bringToFront();
        };

        const resetHighlight = () => {
            geojson.resetStyle();
        };

        const zoomToFeature = (e) => {
            const layer = e.target;
            updateInfo(layer.feature.properties);
            map.fitBounds(e.target.getBounds());
        }

        const clickFeature = (e) => {
            resetHighlight();
            highlightFeature(e);
            zoomToFeature(e);
        };

        const onEachFeature = (feature, layer) => {
            layer.on({
                click: clickFeature
            })
        };

        geojson = L.geoJson(listFeatures, {
            coordsToLatLng: coordsToLatLng,
            style: style,
            onEachFeature: onEachFeature
        }).addTo(map);
    }, []);

    return (
        <div id="map" style={mapStyle}></div>
    )
};
export default Map;
