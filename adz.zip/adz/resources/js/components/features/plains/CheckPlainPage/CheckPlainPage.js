import React from 'react';
import Map from '../Map/Map';
import SearchPanel from "../SearchPanel/SearchPanel";
import './CheckPlainPage.scss';

function CheckPlainDetail() {
    return (
        <div className='plain-container'>
            <SearchPanel/>
            <Map/>
        </div>
    )
}

export default CheckPlainDetail;
