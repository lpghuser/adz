import React, { useState, useEffect } from 'react';
import ImageUploader from "react-images-upload";
import Tesseract from "tesseract.js";
import './UploadImage.scss';

const ImageUploadTool = () => {
    const [picUrl, setPicUrl] = useState([]);
    const [ocrText, setOcrText] = useState([]);

    const onDrop = (_, pictureURL) => {
        setPicUrl(pictureURL);
    };

    useEffect(() => {
        console.log('run')
        picUrl.forEach((picture) =>
            Tesseract.recognize(picture, "vie").then(({ data: { text } }) => {
                alert(text);
            })
        );
    },[picUrl]);
    return (
        <div className='UploadTool'>
            <ImageUploader
                withIcon={false}
                withPreview={true}
                buttonText="Tải sổ đỏ"
                onChange={onDrop}
                imgExtension={[".jpg", ".png", ".gif"]}
                maxFileSize={5242880}
                singleImage={true}
            />
        </div>

    )
};
export default ImageUploadTool;

