const fetchPlainsData = async (url) => {
    const plainsData = await fetch(url);
    const checkPlains =  await plainsData.json();
    return checkPlains.checkPlans.data;
};

export const fetchPlainsList = async (urls) => {
    const requests = urls.map((url) => {
        return fetchPlainsData(url).then((a) => {
            return a
        })
    })
    return Promise.all(requests);
};
//Link: https://anonystick.com/blog-developer/promiseall-javascript-than-thanh-2019052953224827
