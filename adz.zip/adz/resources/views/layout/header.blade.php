<header class="header top-bar-fixed">
    <div class="top-box  " >
        <div class="container">
            <div  class="top-bar color-primary">
                <div class="container clearfix">
                    <div class="pull-left">
                        <ul class="login-menu clearfix">
                            <li><i class="fa fa-phone-square"></i> {{ $phone }}</li>
                            <li><i class="fa fa-envelope"></i> {{ $email }}</li>
                        </ul>
                    </div>
                </div>
            </div>
            <section class="header-inner">
                <div class="container">
                    <div class="logo pull-left pull-sm-up col-sm-6 col-xs-12  text-left">
                        <a href="/">
                            <img src="{{ $logo }}"  style="width:50px; height: 50px;" alt="" class="mini-logo" />
                        </a>
                    </div>
                    <div class="pull-right pull-sm-up col-sm-6 col-xs-12" >
                        @if(isset($user))
                            <ul class="nav navbar-nav clearfix">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                        <img src="/assets/img/user.png" style="width: 35px; height: 35px; border-radius: 50%; margin-right: 5px;" alt=""> {{ $user['full_name'] }}
                                        <i class="icon-dropdown" style="margin-top: 7px;"></i>
                                    </a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="/thong-tin-ca-nhan">Thông tin cá nhân</a>
                                        <a class="dropdown-item" href="/dang-xuat">Đăng xuất</a>
                                    </div>
                                </li>
                            </ul>
                        @else
                            <a href="/dang-ky" class="btn custom-btn-outline" style="margin-right: 1rem; margin-top: 15px;"><i class="fa fa-plus"></i> Đăng ký</a>
                            <a href="/dang-nhap" class="btn custom-btn-outline" style="margin-top: 15px;"><i class="fa fa-sign-in" style="font-size: 15px;"></i> Đăng nhập</a>
                        @endif
                    </div>
                    <div class="pull-left menu"> 
                        <div class="box-navigaion clearfix">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-menu">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </div>
                        <nav class="navbar text-color-primary">
                            <div class="text-right">
                                <button class="navbar-toggler hidden" type="button" data-toggle="collapse" data-target="#main-menu">
                                    &#9776;
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="main-menu">
                                <ul class="nav navbar-nav clearfix">
                                    <li class="nav-item">
                                        <a href="/" style="padding: 10px 0px 0px 0px; margin-right: 1.5rem;">
                                            <img src="{{ $logo }}"  style="width:50px; height: 50px;" alt="" />
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link {{ strpos(Request::url(), '/') !== false  ? 'active' : '' }}" href="/" role="button">
                                            Trang kiểm tra quy hoạch
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </section>
        </div> 
    </div>
    <div class="top-box-mask"></div>
</header>