<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>{{ isset($title) ? $title . " | ANZBDS" : 'ANZBDS' }}</title>
        <link rel="alternate" hreflang="vi" href="https://anzbds.com" />

        <link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
        <link rel="manifest" href="/favicon/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">

        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <meta name="description" content="{{ isset($seo_desc) ? html_entity_decode(strip_tags($seo_desc)) : 'ANZBDS là một nền tảng công nghệ mua bán bất động sản chính chủ đáng tin cậy, giúp đăng tin cho thuê, bán nhà hiệu quả, quản lý mua bán bất động sản dễ dàng, cập nhật thường xuyên giá bất động sản một cách chính xác nhất.'}}" >
        <meta name="keywords" content="{{ isset($keywords) ? $keywords : "ANZBDS, mua bán cho thuê bất động sản, tìm nhà giá tốt, kênh đăng tin bất động sản" }} {{ isset($seo_title) ? "," . $seo_title : "" }}">
        <meta name="author" content="FTC Joint Stock Company"/>
        <meta name="image" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">

        <meta property="fb:app_id" content="1035157113597991" />
        <meta property="og:title" content="{{ isset($seo_title) ? $seo_title : 'Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa' }}">
        <meta property="og:site_name" content="ANZBDS, mua bán cho thuê bất động sản, tìm nhà giá tốt, kênh đăng tin bất động sản">
        <meta property="og:type" content="website" />
        <meta property="og:description" content="{{ isset($seo_desc) ? html_entity_decode(strip_tags($seo_desc)) : 'ANZBDS là một nền tảng công nghệ mua bán bất động sản chính chủ đáng tin cậy, giúp đăng tin cho thuê, bán nhà hiệu quả, quản lý mua bán bất động sản dễ dàng, cập nhật thường xuyên giá bất động sản một cách chính xác nhất.' }}">
        <meta property="og:image" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">
        <meta property="og:url" content="{{ Request::url()}}">
        <meta property="og:image:url" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">
        <meta property="og:image:alt" content="Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa" />
        {{-- <meta property="fb:app_id" content="2193178360937179"> --}}


        <meta name="twitter:title" content="{{ isset($seo_title) ? $seo_title : 'Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa' }}">
        <meta name="twitter:description" content="{{ isset($seo_desc) ? html_entity_decode(strip_tags($seo_desc)) : 'ANZBDS là một nền tảng công nghệ mua bán bất động sản chính chủ đáng tin cậy, giúp đăng tin cho thuê, bán nhà hiệu quả, quản lý mua bán bất động sản dễ dàng, cập nhật thường xuyên giá bất động sản một cách chính xác nhất.'}}">
        <meta name="twitter:image" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">
        <meta name="twitter:card" content="summary_large_image">

        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="title" content="{{ isset($seo_title) ? $seo_title : 'Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa' }}"/>
        <link rel="canonical" href="{{ Request::url()}}" />
        <link rel="shortcut icon" sizes="196x196" href="https://anzbds.com/images/logo.png">
        <link rel="icon" type="image/png" sizes="16x16" href="https://anzbds.com/images/logo.png">

        <script type='application/ld+json'>
        {
            "@context":"https://schema.org",
            "@type":"Organization","url":"{{Request::root()}}",
            "sameAs":[
                "https://www.facebook.com/anzbds"
            ],
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "41 đường 20, Phường Hiệp Bình Chánh, Quận Thủ Đức, Tp. Hồ Chí Minh, Việt Nam",
                "addressRegion": "VN",
                "postalCode": "700000",
                "addressCountry": "VN"
            },
            "@id":"{{Request::root()}}",
            "name":"ANZBDS",
            "logo":"https://anzbds.com/images/logo.png"
        }
        </script>

        <!-- <link rel="stylesheet" href="https://unpkg.com/leaflet@1.1.0/dist/leaflet.css" integrity="sha512-wcw6ts8Anuw10Mzh9Ytw4pylW8+NAD4ch3lqm9lzAsTxg0GFeJgoAtxuCLREZSC5lUXdVyo/7yfsqFjQ4S+aKw==" crossorigin="" /> -->
        <!-- <script src="https://unpkg.com/leaflet@1.1.0/dist/leaflet.js" integrity="sha512-mNqn2Wg7tSToJhvHcqfzLMU6J4mkOImSPTxVZAdo+lcPlk+GhZmYgACEe0x35K7YzW1zJ7XyJV/TT1MrdXvMcA==" crossorigin=""></script> -->

        <!-- <link rel="stylesheet" href="https://leaflet.github.io/Leaflet.markercluster/dist/MarkerCluster.css" /> -->
        <!-- <link rel="stylesheet" href="https://leaflet.github.io/Leaflet.markercluster/dist/MarkerCluster.Default.css" /> -->
        <!-- <script src="https://leaflet.github.io/Leaflet.markercluster/dist/leaflet.markercluster-src.js"></script> -->

        <!-- <link rel="stylesheet" href="source/assets/dist/leaflet.css" />
        <link rel="stylesheet" href="source/assets/dest/dist/MarkerCluster.css" />
        <link rel="stylesheet" href="source/assets/dest/dist/MarkerCluster.Default.css" />
        
        <script src="source/assets/dist/leaflet.js" ></script>
        <script src="source/assets/dist/leaflet.js.map" ></script>
        <script src="source/assets/dist/leaflet-src.esm.js" ></script>
        <script src="source/assets/dist/leaflet-src.js" ></script>
        <script src="source/assets/dist/leaflet-src.js.map" ></script>
        <script src="source/assets/dist/leaflet-src.esm.js.map" ></script>
        
        <script type="text/javascript" src="source/assets/dest/js/markerclusterer.js"></script>
        <script src="source/assets/dest/dist/leaflet.markercluster.js" ></script>
        <script src="source/assets/dest/dist/leaflet.markercluster-src.js" ></script> -->
        
        <!-- <script src="source/assets/src/DistanceGrid.js" ></script>
        <script src="source/assets/src/index.js" ></script>
        <script src="source/assets/src/MarkerCluster.js" ></script>
        <script src="source/assets/src/MarkerCluster.QuickHull.js" ></script>
        <script src="source/assets/src/MarkerCluster.Spiderfier.js" ></script>
        <script src="source/assets/src/MarkerClusterGroup.js" ></script>
        <script src="source/assets/src/MarkerClusterGroup.Refresh.js" ></script>
        <script src="source/assets/src/MarkerOpacity.js" ></script> -->
        
        <link rel="stylesheet" href="/source/assets/dest/libraries/font-awesome/css/font-awesome.min.css" />
        <link rel="stylesheet" href="/source/assets/dest/libraries/tether/dist/css/tether.min.css" />
        <link rel="stylesheet" href="/source/assets/dest/libraries/bootstrap/dist/css/bootstrap.min.css" />
        <link rel="stylesheet" href="/source/assets/dest/css/bootstrap-select.min.css" />
        <link rel="stylesheet" href="/source/assets/dest/libraries/bootstrap-colorpicker-master/dist/css/bootstrap-colorpicker.min.css" />
        <!-- End Bootstrap -->
        <!-- Start Template files -->
        <link rel="stylesheet" href="/source/assets/dest/css/winter-flat.css" />
        <link rel="stylesheet" href="/source/assets/dest/css/custom.css" />
        <!-- End  Template files -->
        <!-- Start owl-carousel -->
        <link rel="stylesheet" href="/source/assets/dest/libraries/owl.carousel/assets/owl.carousel.css" />
        <!-- End owl-carousel -->
        <!-- Start JS MAP  -->
        <!-- <link rel="stylesheet" href="/source/assets/dest/css/map.css" /> -->
        <!-- End JS MAP  -->
        <!-- Start blueimp  -->
        <link rel="stylesheet" href="/source/assets/dest/css/blueimp-gallery.min.css" />
        <!-- End blueimp  -->
        <script src="/source/assets/dest/js/modernizr.custom.js"></script>
        <!-- Start custom template style  -->
        <link rel="stylesheet" href="/source/assets/dest/css/custom_template_style.css" /> 
        <link rel="stylesheet" href="/assets/css/style.css" /> 
        <!-- End custom template style   -->
        <style>
            .mr-3 {
                margin-right: 1rem !important;
            }
            .mb-3 {
                margin-bottom: 1rem !important;
            }
            .product_data_icon {
                width: 16px !important;
                height: 16px !important;
            }
            .right_info {
                bottom: -10px;
                right: 1rem;
                background-color: white;
                position: absolute;
                border-radius: 5px;
                padding: 3px 14px;
                box-shadow: 0 0.1875rem 0.9375rem rgba(0, 0, 0, 0.19);
                background-color: white;
                font-size: 12px;
                float: right;
            }
            .small_verify_icon {
                position: absolute;
                bottom: 0rem;
                width: 4rem !important;
                height: 4rem !important;
                opacity: 0.7;
            }
            .status {
                color: white;
                border: 1px solid;
                padding: 0px 10px;
                background-color: #52096c;
                border-radius: 5px;
                float: right;
            }
            .custom-btn-outline {
                border: 1px solid #52096c;
                color: #52096c;
                border-radius: 5px;
            }
            .custom-btn-outline:hover {
                border: 1px solid #52096c;
                background-color: #52096c;
                color: white;
                border-radius: 5px;
            }
            .custom-btn {
                border: 1px solid #52096c;
                background-color: #52096c;
                color: white;
                border-radius: 5px;
            }
            .custom-btn:hover {
                border: 1px solid #52096c;
                background-color: #52096c;
                color: white;
                border-radius: 5px;
            }
            .color-primary {
                background-color: #52096c !important;
            }
            .menu .nav-link.active {
                background-color: #52096c !important;
            }
            .footer .footer-bottom {
                padding: 10px 0;
            }
            .footer .footer-contant {
                padding-bottom: 30px;
                padding-top: 30px;
            }
            .footer .footer-mask {
                padding-top: 0px !important;
            }
            .ts-card {
                height: 30rem;
                flex-direction: column;
                display: flex;
            }
             h4 {
                margin-bottom: 0px;
            }
            .ts-ribbon-corner:before {
                left: 0.4375rem;
                border-color: #dc3545;
            }
            .ts-ribbon-corner:after {
                bottom: 0.4375rem;
                border-color: #dc3545;
            }
            .ts-ribbon-corner span {
                background-color: #dc3545;
            }
            .text-white {
                color : white !important
            }
            body .btn-scoll-up.btn {
                background-color: #52096c;
            }
            .custom-left-border {
                border-left: 5px solid #ff4c4c;
                padding-left: 5px;
                padding-bottom: 0;
                margin-bottom: 0.4rem;
                color: #52096c;
            }
            .float-right {
                float: right !important;
            }
            .h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
                font-family: sans-serif;
                font-weight: 500;
                line-height: 1.1;
                color: inherit;
            }
            .custom-title {
                color: #52096c;
            }
            a:hover {
                color: #52096c;
            }
            .page-item.active .page-link {
                background-color: #dc3545;
                color: white;
            }
            .pagination li.page-item a:hover {
                background-color: #dc3545 !important;
                color: white;
            }
            .page-item.active .page-link::after {
                border-color: #dc3545 transparent transparent transparent;
            }
            .page-item.disabled .page-link {
                color: #6c757d;
                pointer-events: none;
                cursor: auto;
                background-color: #fff;
                border-color: #dee2e6;
            }
            .mt-3 {
                margin-top: 3rem;
            }
            .mb-2 {
                margin-bottom: 1rem;
            }
            .w-50 {
                width: 50% !important;
            }
        </style>
        @yield('header_style')  

    </head>
    <body >
        <div id="fb-root"></div>
        <div class="container container-wrapper">
            @include('layout.header') 
            @yield('content')
            @include('layout.footer')

            <a class="btn btn-scoll-up color-secondary" id="btn-scroll-up"></a>
        </div>

        <script src="/source/assets/dest/js/jquery-2.2.1.min.js"></script>
        <script src="/source/assets/dest/libraries/jquery.mobile/jquery.mobile.custom.min.js"></script>
        <script src="/source/assets/dest/libraries/tether/dist/js/tether.min.js"></script>
        <script src="/source/assets/dest/libraries/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="/source/assets/dest/js/bootstrap-select.min.js"></script>
        <script src="/source/assets/dest/libraries/bootstrap-colorpicker-master/dist/js/bootstrap-colorpicker.min.js"></script>
        <script src="/source/assets/dest/js/winter-flat.js"></script>
        <script src="/source/assets/dest/libraries/owl.carousel/owl.carousel.min.js"></script>
        <!-- <script src="http://maps.googleapis.com/maps/api/js?libraries=weather,geometry,visualization,places,drawing&amp;&key=AIzaSyArqScnm2PDzRvEIAGXpULA4AOvVe8LtCY&amp;&scale=2" type="text/javascript"></script> -->
        <!-- <script type="text/javascript" src="/source/assets/dest/js/map_infobox.js"></script> -->
        <!-- <script src="/source/assets/dest/js/map.js" type="text/javascript"></script> -->
        <script src="/source/assets/dest/js/blueimp-gallery.min.js" type="text/javascript"></script>
        <script src="/source/assets/dest/js/custom_template_style.js" type="text/javascript"></script>
        <script src="/source/assets/dest/js/facebook.js" type="text/javascript"></script>
        <script>
            $(document).ready(function($) {
                    $("[data-bg-color], [data-bg-image], [data-bg-pattern]").each(function() {
                    var $this = $(this);
            
                    if( $this.hasClass("ts-separate-bg-element") ){
                        $this.append('<div class="ts-background">');
            
                        // Background Color
            
                        if( $("[data-bg-color]") ){
                            $this.find(".ts-background").css("background-color", $this.attr("data-bg-color") );
                        }
            
                        // Background Image
            
                        if( $this.attr("data-bg-image") !== undefined ){
                            $this.find(".ts-background").append('<div class="ts-background-image">');
                            $this.find(".ts-background-image").css("background-image", "url("+ $this.attr("data-bg-image") +")" );
                            $this.find(".ts-background-image").css("background-size", $this.attr("data-bg-size") );
                            $this.find(".ts-background-image").css("background-position", $this.attr("data-bg-position") );
                            $this.find(".ts-background-image").css("opacity", $this.attr("data-bg-image-opacity") );
            
                            $this.find(".ts-background-image").css("background-size", $this.attr("data-bg-size") );
                            $this.find(".ts-background-image").css("background-repeat", $this.attr("data-bg-repeat") );
                            $this.find(".ts-background-image").css("background-position", $this.attr("data-bg-position") );
                            $this.find(".ts-background-image").css("background-blend-mode", $this.attr("data-bg-blend-mode") );
                        }
            
                        // Parallax effect
            
                        if( $this.attr("data-bg-parallax") !== undefined ){
                            $this.find(".ts-background-image").addClass("ts-parallax-element");
                        }
                    }
                    else {
            
                        if(  $this.attr("data-bg-color") !== undefined ){
                            $this.css("background-color", $this.attr("data-bg-color") );
                            if( $this.hasClass("btn") ) {
                                $this.css("border-color", $this.attr("data-bg-color"));
                            }
                        }
            
                        if( $this.attr("data-bg-image") !== undefined ){
                            $this.css("background-image", "url("+ $this.attr("data-bg-image") +")" );
            
                            $this.css("background-size", $this.attr("data-bg-size") );
                            $this.css("background-repeat", $this.attr("data-bg-repeat") );
                            $this.css("background-position", $this.attr("data-bg-position") );
                            $this.css("background-blend-mode", $this.attr("data-bg-blend-mode") );
                        }
            
                        if( $this.attr("data-bg-pattern") !== undefined ){
                            $this.css("background-image", "url("+ $this.attr("data-bg-pattern") +")" );
                        }
            
                    }
                });
            });
        </script>
        @yield('footer_script')

    </body>
</html>