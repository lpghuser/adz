<footer class="footer footer_fix_bottom">
    <div class="container footer-mask">
        <div class="container footer-contant">
            <div class="row">
                <div class="col-md-6">
                    <a href="#" class="brand">
                        <img src="{{ $logo }}" style="width:50px; height: 50px;" alt=""> <strong style="color: #dc3545 !important;">CHẠM LIỀN TAY - CÓ NGAY BẤT ĐỘNG SẢN</strong> 
                    </a>
                    <address class="ts-text-color-light text-muted " style="margin-top: 0.5rem;">
                        <strong class="text-white">Head office: </strong> <span style="color: #fefefe;; font-size: 12px;">{{ $address }}</span>
                        <br>
                        <strong class="text-white" >Email: </strong>
                        <a href="mailto:{{ $email }}" class="btn-link" style="font-size: 12px;">{{ $email }}</a>
                        <br>
                        <strong class="text-white" >Hotline: </strong>
                        <a href="tel:{{ $phone }}" class="btn-link" style="font-size: 12px;">{{ $phone }}</a>
                    </address>
                    <a href="{{ $urlClient }}lien-he" target="_blank" class="btn custom-btn-outline mb-4">Liên hệ với chúng tôi</a>
                </div>

                <div class="col-md-2">
                    <h4 class="text-white">VỀ ANZBDS</h4>
                    <nav class="nav flex-row flex-md-column mb-4" style="display: inline-grid;">
                        <a href="{{ $urlClient }}lien-he" target="_blank" class="nav-link mb-3">Liên hệ</a>
                        <a href="{{ $urlClient }}gioi-thieu" target="_blank" class="nav-link mb-3">Giới thiệu</a>
                        <a href="{{ $urlClient }}tuyen-dung" target="_blank" class="nav-link mb-3">Tuyển dụng</a>
                    </nav>
                </div>

                <div class="col-md-2">
                    <h4 class="text-white">DỊCH VỤ</h4>
                    <nav class="nav flex-row flex-md-column mb-4" style="display: inline-grid;">
                        <a href="{{ $urlClient }}mua/bat-dong-san" target="_blank" class="nav-link mb-3">Mua bán</a> 
                        <a href="{{ $urlClient }}thue/bat-dong-san" target="_blank" class="nav-link mb-3">Cho thuê</a>
                        <a href="/ky-gui-bds/submit" class="nav-link mb-3">Ký gửi BĐS</a>
                    </nav>
                </div>

                <div class="col-md-2" style="display: inline-grid;">
                    <!-- <h4 class="custom-title">Dịch vụ</h4> -->
                    <a href="https://apps.apple.com/vn/app/anzbds/id1519578125?l=vi" class="nav-link icon-device"><img src="/assets/img/app-store-badge-vi.png" style="width:100%; height: 40px; padding: 0px 15px;" alt=""></a><br>
                    <a href="https://play.google.com/store/apps/details?id=com.ftcjsc.anzbds" class="nav-link icon-device" style=""><img src="/assets/img/google-play-badge-vi.png" style="width:100%; height: 40px; padding: 0px 15px;" alt=""></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container text-center">
                <div class="ts-copyright"><span class="">2020 © <a href="https://anzbds.com/" class="primary_color;">ANZBDS</a> - All Rights Reserved </span></div>
            </div>
        </div>
    </div>
</footer>