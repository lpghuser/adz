@extends('layout.master')
@section('header_style')
<style>

.content-item {
	background-color:#FFFFFF;
}

.content-item.grey {
	background-color:#F0F0F0;
	padding:50px 0;
	height:100%;
}

.content-item h2 {
	font-weight:700;
	font-size:35px;
	line-height:45px;
	text-transform:uppercase;
	margin:20px 0;
}

.content-item h3 {
	font-weight:400;
	font-size:20px;
	color:#555555;
	margin:10px 0 15px;
	padding:0;
}

.content-headline {
	height:1px;
	text-align:center;
	margin:20px 0 70px;
}

.content-headline h2 {
	background-color:#FFFFFF;
	display:inline-block;
	margin:-20px auto 0;
	padding:0 20px;
}

.grey .content-headline h2 {
	background-color:#F0F0F0;
}

.content-headline h3 {
	font-size:14px;
	color:#AAAAAA;
	display:block;
}


#comments {
    box-shadow: 0 -1px 6px 1px rgba(0,0,0,0.1);
	background-color:#FFFFFF;
	margin-bottom: 3rem;
}

#comments form {
	margin-bottom: 0px;
}

#comments .btn {
	margin-top:7px;
}

#comments form fieldset {
	clear:both;
}

#comments form textarea {
	height:100px;
}

#comments .media {
	border-top:1px dashed #DDDDDD;
	padding: 10px 0;
	margin:0;
}

#comments .media > .pull-left {
    margin-right:20px;
}

#comments .media img {
	max-width:95px;
}

#comments .media h4 {
	margin:0 0 10px;
}

#comments .media h4 span {
	font-size:14px;
	color:#999999;
}

#comments .media p {
	margin-bottom:15px;
	text-align:justify;
}

#comments .media-detail {
	margin:0;
}

#comments .media-detail li {
	color:#AAAAAA;
	font-size:12px;
	padding-right: 10px;
	font-weight:600;
}

#comments .media-detail a:hover {
	text-decoration:underline;
}

#comments .media-detail li:last-child {
	padding-right:0;
}

#comments .media-detail li i {
	color:#666666;
	font-size:15px;
	margin-right:10px;
}
.comment_content {
    max-width: unset;
    font-size: 16px;
    width: 100% !important;
}
.w-100 {
    width : 100% !important;
}
.form-control:focus, .custom-select:focus {
    border : 1px solid;
    border-color: #52096c !important;
}

</style>
@endsection

@section('content')
<main class="main section-color-primary" style="margin-top: 100px;">
    <div class="container">
        <h2 class="mb-2 mt-3 custom-left-border">THÔNG TIN QUY HOẠCH {{ $plan['city_name'] }}</h2>
        <div class="card-box" >
            <div>
                <span>Website: </span>
                <a href="{{ $plan['website'] ? $plan['website'] : 'javascript:void(0)' }}" > <span>{{ $plan['website'] ? 'link website' : 'Đang cập nhật' }}</span></a>
            </div>
            <div>
                <span>Android: </span>
                <a href="{{ $plan['android'] ? $plan['android'] : 'javascript:void(0)' }}" > <span>{{ $plan['android'] ? 'link android' : 'Đang cập nhật' }}</span></a>
            </div>
            <div>
                <span>Ios: </span>
                <a href="{{ $plan['ios'] ? $plan['ios'] : 'javascript:void(0)' }}" > <span>{{ $plan['ios'] ? 'link ios' : 'Đang cập nhật' }}</span></a>
            </div>
        </div>
        <br>
        <br class="mb-3">
        <section class="content-item" id="comments" class="mb-3">
            <div class="container">
                <div class="row w-100">
                    <div class="col-sm-12">
                        <form class="comment_form" method="POST" action="/comment/save">
                            {{ csrf_field() }}
                            <input type="hidden" name="plan_id" value="{{ $plan_id }}">
                            <h3 >Bình luận của bạn</h3>
                            <div class="media" style="border-top: unset">
                                <a class="pull-left" href="#"><img class="media-object" src="/assets/img/user.png" alt=""></a>

                                <div class="media-body" style="padding-top: 22px;">
                                    <input type="text" name="comment" class="form-control" id="message" placeholder="Your message" required="">
                                </div>
                            </div>
                        </form>

                        <h5 class="text-muted text-right">{{ count($comments) }} Bình luận</h5>
                        @foreach($comments as $idx => $comment)
                            <div class="media">
                                <a class="pull-left" href="#"><img class="media-object" src="/assets/img/user.png" alt=""></a>

                                <div class="media-body">
                                    <h4 class="media-heading">{{ $comment->name}}
                                        <span class="text-muted float-left"> {{ $comment->created_at->diffForHumans()  }}</span>
                                    </h4>
                                    <p class="comment_content">{{ $comment->comment }}</p>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>
@endsection

@section('footer_script')
<script>
$(document).ready(() => {

    $('.comment_form').keypress((e) => {
        if (e.which === 13) {
            var message = $("#message").val();
            if(message) {
                $('.comment_form').submit();
            }
        }
    })
});
</script>
@endsection
