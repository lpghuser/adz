<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
{{--    <title>{{ isset($title) ? $title . " | ANZBDS" : 'ANZBDS' }}</title>--}}
    <link rel="alternate" hreflang="vi" href="https://anzbds.com" />

    <link rel="apple-touch-icon" sizes="57x57" href="/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
    <link rel="manifest" href="/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

{{--    <meta name="description" content="{{ isset($seo_desc) ? html_entity_decode(strip_tags($seo_desc)) : 'ANZBDS là một nền tảng công nghệ mua bán bất động sản chính chủ đáng tin cậy, giúp đăng tin cho thuê, bán nhà hiệu quả, quản lý mua bán bất động sản dễ dàng, cập nhật thường xuyên giá bất động sản một cách chính xác nhất.'}}" >--}}
{{--    <meta name="keywords" content="{{ isset($keywords) ? $keywords : "ANZBDS, mua bán cho thuê bất động sản, tìm nhà giá tốt, kênh đăng tin bất động sản" }} {{ isset($seo_title) ? "," . $seo_title : "" }}">--}}
    <meta name="author" content="FTC Joint Stock Company"/>
{{--    <meta name="image" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">--}}

    <meta property="fb:app_id" content="1035157113597991" />
{{--    <meta property="og:title" content="{{ isset($seo_title) ? $seo_title : 'Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa' }}">--}}
    <meta property="og:site_name" content="ANZBDS, mua bán cho thuê bất động sản, tìm nhà giá tốt, kênh đăng tin bất động sản">
    <meta property="og:type" content="website" />
{{--    <meta property="og:description" content="{{ isset($seo_desc) ? html_entity_decode(strip_tags($seo_desc)) : 'ANZBDS là một nền tảng công nghệ mua bán bất động sản chính chủ đáng tin cậy, giúp đăng tin cho thuê, bán nhà hiệu quả, quản lý mua bán bất động sản dễ dàng, cập nhật thường xuyên giá bất động sản một cách chính xác nhất.' }}">--}}
{{--    <meta property="og:image" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">--}}
{{--    <meta property="og:url" content="{{ Request::url()}}">--}}
{{--    <meta property="og:image:url" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">--}}
    <meta property="og:image:alt" content="Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa" />
    {{-- <meta property="fb:app_id" content="2193178360937179"> --}}


{{--    <meta name="twitter:title" content="{{ isset($seo_title) ? $seo_title : 'Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa' }}">--}}
{{--    <meta name="twitter:description" content="{{ isset($seo_desc) ? html_entity_decode(strip_tags($seo_desc)) : 'ANZBDS là một nền tảng công nghệ mua bán bất động sản chính chủ đáng tin cậy, giúp đăng tin cho thuê, bán nhà hiệu quả, quản lý mua bán bất động sản dễ dàng, cập nhật thường xuyên giá bất động sản một cách chính xác nhất.'}}">--}}
{{--    <meta name="twitter:image" content="{{ isset($seo_image) ? $seo_image : 'https://anzbds.com/images/logo.png' }}">--}}
    <meta name="twitter:card" content="summary_large_image">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
{{--    <meta name="title" content="{{ isset($seo_title) ? $seo_title : 'Ứng dụng ANZBDS - Ứng dụng kết nối mua, bán, cho thuê bất động sản và hơn thế nữa' }}"/>--}}
    <link rel="canonical" href="{{ Request::url()}}" />
    <link rel="shortcut icon" sizes="196x196" href="https://anzbds.com/images/logo.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://anzbds.com/images/logo.png">

    <script type='application/ld+json'>
        {
            "@context":"https://schema.org",
            "@type":"Organization","url":"{{Request::root()}}",
            "sameAs":[
                "https://www.facebook.com/anzbds"
            ],
            "address": {
                "@type": "PostalAddress",
                "streetAddress": "41 đường 20, Phường Hiệp Bình Chánh, Quận Thủ Đức, Tp. Hồ Chí Minh, Việt Nam",
                "addressRegion": "VN",
                "postalCode": "700000",
                "addressCountry": "VN"
            },
            "@id":"{{Request::root()}}",
            "name":"ANZBDS",
            "logo":"https://anzbds.com/images/logo.png"
        }
        </script>

    <!-- <link rel="stylesheet" href="https://unpkg.com/leaflet@1.1.0/dist/leaflet.css" integrity="sha512-wcw6ts8Anuw10Mzh9Ytw4pylW8+NAD4ch3lqm9lzAsTxg0GFeJgoAtxuCLREZSC5lUXdVyo/7yfsqFjQ4S+aKw==" crossorigin="" /> -->
    <!-- <script src="https://unpkg.com/leaflet@1.1.0/dist/leaflet.js" integrity="sha512-mNqn2Wg7tSToJhvHcqfzLMU6J4mkOImSPTxVZAdo+lcPlk+GhZmYgACEe0x35K7YzW1zJ7XyJV/TT1MrdXvMcA==" crossorigin=""></script> -->

    <!-- <link rel="stylesheet" href="https://leaflet.github.io/Leaflet.markercluster/dist/MarkerCluster.css" /> -->
    <!-- <link rel="stylesheet" href="https://leaflet.github.io/Leaflet.markercluster/dist/MarkerCluster.Default.css" /> -->
    <!-- <script src="https://leaflet.github.io/Leaflet.markercluster/dist/leaflet.markercluster-src.js"></script> -->

    <!-- <link rel="stylesheet" href="source/assets/dist/leaflet.css" />
    <link rel="stylesheet" href="source/assets/dest/dist/MarkerCluster.css" />
    <link rel="stylesheet" href="source/assets/dest/dist/MarkerCluster.Default.css" />

    <script src="source/assets/dist/leaflet.js" ></script>
    <script src="source/assets/dist/leaflet.js.map" ></script>
    <script src="source/assets/dist/leaflet-src.esm.js" ></script>
    <script src="source/assets/dist/leaflet-src.js" ></script>
    <script src="source/assets/dist/leaflet-src.js.map" ></script>
    <script src="source/assets/dist/leaflet-src.esm.js.map" ></script>

    <script type="text/javascript" src="source/assets/dest/js/markerclusterer.js"></script>
    <script src="source/assets/dest/dist/leaflet.markercluster.js" ></script>
    <script src="source/assets/dest/dist/leaflet.markercluster-src.js" ></script> -->

    <!-- <script src="source/assets/src/DistanceGrid.js" ></script>
    <script src="source/assets/src/index.js" ></script>
    <script src="source/assets/src/MarkerCluster.js" ></script>
    <script src="source/assets/src/MarkerCluster.QuickHull.js" ></script>
    <script src="source/assets/src/MarkerCluster.Spiderfier.js" ></script>
    <script src="source/assets/src/MarkerClusterGroup.js" ></script>
    <script src="source/assets/src/MarkerClusterGroup.Refresh.js" ></script>
    <script src="source/assets/src/MarkerOpacity.js" ></script> -->

    <link rel="stylesheet" href="/source/assets/dest/libraries/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/source/assets/dest/libraries/tether/dist/css/tether.min.css" />
    <link rel="stylesheet" href="/source/assets/dest/libraries/bootstrap/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/source/assets/dest/css/bootstrap-select.min.css" />
    <link rel="stylesheet" href="/source/assets/dest/libraries/bootstrap-colorpicker-master/dist/css/bootstrap-colorpicker.min.css" />
    <!-- End Bootstrap -->
    <!-- Start Template files -->
    <link rel="stylesheet" href="/source/assets/dest/css/winter-flat.css" />
    <link rel="stylesheet" href="/source/assets/dest/css/custom.css" />
    <!-- End  Template files -->
    <!-- Start owl-carousel -->
    <link rel="stylesheet" href="/source/assets/dest/libraries/owl.carousel/assets/owl.carousel.css" />
    <!-- End owl-carousel -->
    <!-- Start JS MAP  -->
    <!-- <link rel="stylesheet" href="/source/assets/dest/css/map.css" /> -->
    <!-- End JS MAP  -->
    <!-- Start blueimp  -->
    <link rel="stylesheet" href="/source/assets/dest/css/blueimp-gallery.min.css" />
    <!-- End blueimp  -->
    <script src="/source/assets/dest/js/modernizr.custom.js"></script>
    <!-- Start custom template style  -->
    <link rel="stylesheet" href="/source/assets/dest/css/custom_template_style.css" />
    <link rel="stylesheet" href="/assets/css/style.css" />
</head>
<body>
    <div id= "root">
    </div>
    <script src="{{asset('js/app.js')}}"></script>
    <script src="/source/assets/dest/js/jquery-2.2.1.min.js"></script>
    <script src="/source/assets/dest/libraries/jquery.mobile/jquery.mobile.custom.min.js"></script>
    <script src="/source/assets/dest/libraries/tether/dist/js/tether.min.js"></script>
    <script src="/source/assets/dest/libraries/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="/source/assets/dest/js/bootstrap-select.min.js"></script>
    <script src="/source/assets/dest/libraries/bootstrap-colorpicker-master/dist/js/bootstrap-colorpicker.min.js"></script>
    <script src="/source/assets/dest/js/winter-flat.js"></script>
    <script src="/source/assets/dest/libraries/owl.carousel/owl.carousel.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.1.0/dist/leaflet.css" />
    <!-- <script src="http://maps.googleapis.com/maps/api/js?libraries=weather,geometry,visualization,places,drawing&amp;&key=AIzaSyArqScnm2PDzRvEIAGXpULA4AOvVe8LtCY&amp;&scale=2" type="text/javascript"></script> -->
    <!-- <script type="text/javascript" src="/source/assets/dest/js/map_infobox.js"></script> -->
    <!-- <script src="/source/assets/dest/js/map.js" type="text/javascript"></script> -->
    <script src="/source/assets/dest/js/blueimp-gallery.min.js" type="text/javascript"></script>
    <script src="/source/assets/dest/js/custom_template_style.js" type="text/javascript"></script>
    <script src="/source/assets/dest/js/facebook.js" type="text/javascript"></script>
</body>
</html>
