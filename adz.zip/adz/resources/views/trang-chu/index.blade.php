@extends('layout.master')
@section('header_style')
<style>
  
    .col-md-3 {
        width: 23%;
    }
    .card-box {
        background-color: white;
        padding: 10px;
        margin: 10px;
        box-shadow: 0 .125rem .3125rem rgba(0, 0, 0, .1);
        border-radius: .1875rem;
        transition: .3s ease;
    }
    .card-box:hover {
        box-shadow: 0 0.3125rem 1.5625rem rgba(0, 0, 0, .25);
        color: inherit;
        -webkit-transform: translateY(-0.3125rem);
        transform: translateY(-0.3125rem);
    }
  
    .font-weight-bold {
        font-weight: bold;
    }
</style>
@endsection

@section('content')
<main class="main section-color-primary" style="margin-top: 100px;">
    <div class="container">
        <h2 class="mb-2 mt-3 custom-left-border">DANH SÁCH KIỂM TRA QUY HOẠCH</h2>
        <div class="row">
            @foreach($checkPlans['data'] as $idx => $plan )
                <div class="col-md-3 card-box" >
                    <div>
                        <a href="/chi-tiet-quy-hoach/{{ $plan['id'] }}/{{ str_slug($plan['city_name']) }}"> 
                            <span>Thành phố: </span>
                            <span class="font-weight-bold">{{ $plan['city_name'] }}</span>
                        </a>
                    </div>
                    <div>
                        <span>Website: </span>
                        <a href="{{ $plan['website'] ? $plan['website'] : 'javascript:void(0)' }}" > <span>{{ $plan['website'] ? 'link website' : 'Đang cập nhật' }}</span></a>
                    </div>
                    <div>
                        <span>Android: </span>
                        <a href="{{ $plan['android'] ? $plan['android'] : 'javascript:void(0)' }}" > <span>{{ $plan['android'] ? 'link android' : 'Đang cập nhật' }}</span></a>
                    </div>
                    <div>
                        <span>Ios: </span>
                        <a href="{{ $plan['ios'] ? $plan['ios'] : 'javascript:void(0)' }}" > <span>{{ $plan['ios'] ? 'link ios' : 'Đang cập nhật' }}</span></a>
                    </div>
                </div>
            @endforeach
        </div>

        <section id="pagination" style="display: flex">
            <div class="container center_pag">
                @if ($checkPlans['last_page'] > 1)
                    <nav aria-label="Page navigation">
                        <ul class="pagination ts-center__horizontal">
                            <li class="{{ ($checkPlans['current_page'] == 1) ? ' disabled' : '' }} page-item">
                                <a class=" page-link ts-btn-arrow" href="{{ Request::url() . '?page=' . ($checkPlans['current_page'] - 1) . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}" ><</a>
                            </li>
                            @if($checkPlans['last_page'] < 5)
                                @for ($i = 1; $i <= $checkPlans['last_page']; $i++)
                                    <li class="{{ ($checkPlans['current_page'] == $i) ? ' active' : '' }} page-item">
                                        <a class=" page-link " href="{{ Request::url() . '?page=' . $i . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}">{{ $i }}</a>
                                    </li>
                                @endfor
                            @else 
                                @if($checkPlans['current_page'] > 5)
                                    <li class="{{ ($checkPlans['current_page'] == 1) ? ' active' : '' }} page-item">
                                        <a class=" page-link " href="{{ Request::url() . '?page=' . 1 . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}">{{ 1 }}</a>
                                    </li>
                                    <li class="{{ ($checkPlans['current_page'] == 2) ? ' active' : '' }} page-item">
                                        <a class=" page-link " href="{{ Request::url() . '?page=' . 2 . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}">{{ 2 }}</a>
                                    </li>
                                    <li class="page-item">
                                        <a class=" page-link " href="javascript:void(0)">...</a>
                                    </li>
                                @endif
                                @for ( $i = ($checkPlans['current_page'] < 6 ? ($checkPlans['current_page'] - 2*$checkPlans['current_page'] + 1) : -2); $i < (($checkPlans['current_page'] < $checkPlans['last_page'] - 3) ? '3' : ($checkPlans['last_page'] - $checkPlans['current_page'] + 1)); $i++)
                                    <li class="{{ ($checkPlans['current_page'] == ($checkPlans['current_page'] + $i)) ? ' active' : '' }} page-item">
                                        <a class=" page-link " href="{{ Request::url() . '?page=' . ($checkPlans['current_page'] + $i) . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}">{{ $checkPlans['current_page'] + $i }}</a>
                                    </li>
                                @endfor
                                @if($checkPlans['current_page'] < $checkPlans['last_page'] - 3)
                                    <li class="page-item">
                                        <a class=" page-link " href="javascript:void(0)">...</a>
                                    </li>
                                    <li class="{{ ($checkPlans['current_page'] == $checkPlans['last_page']) ? ' active' : '' }} page-item">
                                        <a class=" page-link " href="{{ Request::url() . '?page=' . $checkPlans['last_page'] . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}">{{ $checkPlans['last_page'] }}</a>
                                    </li>
                                @endif
                            @endif
                            <li class="{{ ($checkPlans['current_page'] == $checkPlans['last_page']) ? ' disabled' : '' }} page-item">
                                <a class="page-link ts-btn-arrow" href="{{ Request::url() . '?page=' . ($checkPlans['current_page'] + 1) . (isset($filterData['filterMess']) ? '&' . $filterData['filterMess'] : '') }}">></a>
                            </li>
                        </ul>
                    </nav>
                @endif
            </div>
        </section>
    <div>
    <section id="latest-listings" class="ts-block pt-4 pb-0 bg-white">
        <div class="container">

            <div class="ts-title mb-0">
                <h2 class="mb-2 custom-left-border">BĐS ĐANG BÁN
                    <a href="{{ $urlClient }}mua/bat-dong-san"  target="_blank" class="btn custom-btn-outline ts-btn-border-danger float-right">Xem tất cả</a>
                </h2>
            </div>

            <div class="row">
                @foreach($prodsForSale['data'] as $idxProd => $product)
                    <div class="col-sm-6 col-lg-3">
                        <div class="card ts-item ts-card">
                            @if( $product['is_public'] )
                                <div class="ts-ribbon-corner">
                                    <span style="text-transform: unset;font-weight: bolder">Thưởng <br> {{ $product['introduce_fee'] ? $product['introduce_fee'] : 'cho giới thiệu' }} đ</span>
                                </div>
                            @endif

                            <a href="{{ $urlClient }}bat-dong-san/{{ $product['id'] }}/{{ str_slug($product['name']) }}" target="_blank" class="card-img" data-bg-image="{{ $product['medias'] ? $product['medias'][0]['source'] : '' }}">
                                <div class="ts-item__info-badge">
                                    <span style="color: #52096c" class="font-weight-bold">$ {{ $product['price'] }}</span>  
                                </div>
                                <div class="right_info">
                                    <span style="left: 100px" alt="Số người xem {{ $product['name'] }}"><i class="fa fa-eye"></i> {{ isset($product['view_count']) ? $product['view_count'] : '50' }}</span>
                                    <span style="left: 100px; margin-left: 15px;" alt="Số người quan tâm {{ $product['name'] }}"><i class="fa fa-taxi"></i> {{ isset($product['appointment_count']) ? $product['appointment_count'] : '79' }}</span>
                                </div>
                                @if($product['is_verify'])
                                    <img src="{{ $verify_img }}" class="small_verify_icon" alt="">
                                @endif
                            </a>

                            <div class="card-body">
                                <div class="mb-2">
                                    <a href="{{ $urlClient }}bat-dong-san/{{ $product['id'] }}/{{ str_slug($product['name']) }}" target="_blank"><h4 class="mb-0">{{ str_limit(html_entity_decode(strip_tags($product['name'])), 35) }}</h4></a>
                                    <p>
                                        <i class="fa fa-map-marker-alt mr-2"></i>
                                        {{ $product['ward_name'] . ', ' . $product['district_name'] . ', ' . $product['city_name'] }}
                                    </p>
                                </div>
                                <div class="ts-description-lists">
                                    <dl>
                                        <dt><img class="product_data_icon" src="/assets/img/land.png" alt=""></dt>
                                        <dd>{{ $product['square'] ? $product['square'] : '0' }}m<sup>2</sup></dd>
                                    </dl>
                                    <dl style="margin-right: 1rem">
                                        <dt><img class="product_data_icon" src="/assets/img/bed.png" alt=""></dt>
                                        <dd class="text-center">{{ $product['bedroom_num'] ? $product['bedroom_num'] : '0' }}</dd>
                                    </dl>
                                    <dl style="margin-right: 1rem">
                                        <dt><img class="product_data_icon" src="/assets/img/bathroom.png" alt=""></dt>
                                        <dd class="text-center">{{ $product['bathroom_num'] ? $product['bathroom_num'] : '0' }}</dd>
                                    </dl>
                                    @if($product['direction_name'] != "Không xác định")
                                    <dl style="margin-right: 0rem">
                                        <dt><img class="product_data_icon" src="/assets/img/compass.png" alt=""></dt>
                                        <dd class="text-center">{{ $product['direction_name'] ? $product['direction_name'] : '0' }}</dd>
                                    </dl>
                                    @endif
                                </div>
                            </div>

                            <div href="{{ $urlClient }}bat-dong-san/{{ $product['id'] }}/{{ str_slug($product['name']) }}" target="_blank" class="card-footer">
                                
                                @if(isset($product['available_status_name']) && ($product['available_status_id'] === 2 || $product['available_status_id'] === 3) )
                                    <span class="float-right text-center status">{{ isset($product['available_status_name']) ? $product['available_status_name'] : '' }}</span>
                                @else 
                                    <span class="float-right text-center status">{{ isset($product['legal_status_name']) ? $product['legal_status_name'] : '' }}</span>
                                @endif
                              
                            </div>

                        </div>
                    </div>
                @endforeach
           </div>
        </div>
    </section>

    <section id="latest-listings" class="ts-block pt-4">
        <div class="container">

            <div class="ts-title mb-0">
                <h2 class="mb-2 custom-left-border">BĐS CHO THUÊ
                    <a href="{{ $urlClient }}thue/bat-dong-san" target="_blank" class="btn custom-btn-outline ts-btn-border-danger float-right">Xem tất cả</a>
                </h2>
            </div>

            <div class="row">
                @if(isset($prodsForRent['data']) && $prodsForRent['data'])
                    @foreach($prodsForRent['data'] as $idxProd => $product)
                        <div class="col-sm-6 col-lg-3">
                            <div class="card ts-item ts-card">
                                @if( $product['is_public'] )
                                    <div class="ts-ribbon-corner">
                                        <span style="text-transform: unset;font-weight: bolder">Thưởng <br> {{ $product['introduce_fee'] ? $product['introduce_fee'] : 'cho giới thiệu' }} đ</span>
                                    </div>
                                @endif
                                
                                <a href="{{ $urlClient }}bat-dong-san/{{ $product['id'] }}/{{ str_slug($product['name']) }}" target="_blank" class="card-img" data-bg-image="{{ $product['medias'] ? $product['medias'][0]['source'] : '' }}">
                                    <div class="ts-item__info-badge">
                                        <span style="color: #52096c" class="font-weight-bold">$ {{ $product['price'] }}</span>  
                                    </div>
                                    <div class="right_info">
                                        <span style="left: 100px" alt="Số người xem {{ $product['name'] }}"><i class="fa fa-eye"></i> {{ isset($product['view_count']) ? $product['view_count'] : '50' }}</span>
                                        <span style="left: 100px; margin-left: 15px;" alt="Số người quan tâm {{ $product['name'] }}"><i class="fa fa-taxi"></i> {{ isset($product['appointment_count']) ? $product['appointment_count'] : '79' }}</span>
                                    </div>
                                    @if($product['is_verify'])
                                        <img src="{{ $verify_img }}" class="small_verify_icon" alt="">
                                    @endif
                                </a>

                                <div class="card-body">
                                    <div class="mb-2">
                                    <a href="{{ $urlClient }}bat-dong-san/{{ $product['id'] }}/{{ str_slug($product['name']) }}" target="_blank"><h4 class="mb-0">{{ str_limit(html_entity_decode(strip_tags($product['name'])), 35) }}</h4></a>
                                        <p>
                                            <i class="fa fa-map-marker-alt mr-2"></i>
                                            {{ $product['ward_name'] . ', ' . $product['district_name'] . ', ' . $product['city_name'] }}
                                        </p>
                                    </div>
                                    <div class="ts-description-lists">
                                        <dl>
                                            <dt><img class="product_data_icon" src="/assets/img/land.png" alt=""></dt>
                                            <dd>{{ $product['square'] ? $product['square'] : '0' }}m<sup>2</sup></dd>
                                        </dl>
                                        <dl style="margin-right: 1rem">
                                            <dt><img class="product_data_icon" src="/assets/img/bed.png" alt=""></dt>
                                            <dd class="text-center">{{ $product['bedroom_num'] ? $product['bedroom_num'] : '0' }}</dd>
                                        </dl>
                                        <dl style="margin-right: 1rem">
                                            <dt><img class="product_data_icon" src="/assets/img/bathroom.png" alt=""></dt>
                                            <dd class="text-center">{{ $product['bathroom_num'] ? $product['bathroom_num'] : '0' }}</dd>
                                        </dl>
                                        @if($product['direction_name'] != "Không xác định")
                                        <dl style="margin-right: 0rem">
                                            <dt><img class="product_data_icon" src="/assets/img/compass.png" alt=""></dt>
                                            <dd class="text-center">{{ $product['direction_name'] ? $product['direction_name'] : '0' }}</dd>
                                        </dl>
                                        @endif
                                    </div>
                                </div>

                                <div href="{{ $urlClient }}bat-dong-san/{{ $product['id'] }}/{{ str_slug($product['name']) }}" target="_blank" class="card-footer">
                                   
                                    @if(isset($product['available_status_name']) && ( $product['available_status_id'] === 2 || $product['available_status_id'] === 3) )
                                        <span class="float-right text-center status">{{ isset($product['available_status_name']) ? $product['available_status_name'] : '' }}</span>
                                    @else 
                                        <span class="float-right text-center status">{{ isset($product['legal_status_name']) ? $product['legal_status_name'] : '' }}</span>
                                    @endif
                                  
                                </div>

                            </div>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
    </section>

    </div>
</main>

@endsection

@section('footer_script')

@endsection