@extends('layout.master')
@section('content')
<main class="main section-color-primary">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="top-title">
                    <ul class="breadcrumb">
                        <li class="item"><a href="/"> Trang chủ </a></li>
                        <li class="item"> Đăng ký </li>
                    </ul>
                    <h1 class="h-side-title page-title page-title-big text-color-primary">Đăng ký tài khoản</h1> 
                </section> 
                    <div class="row">
                        <div class="container">
		                    <div id="content">
                            	<form action="{{route('post_dangky')}}" method="post" class="beta-form-checkout">
                                    {{ csrf_field() }}
                                    <div class="row">
                                        <div class="col-sm-3"></div>
                                        @if(Session::has('thanhcong'))
                                            <div class="alert alert-success">{{Session::get('thanhcong')}}</div>
                                        @endif
                        				<div class="col-sm-6"  style="margin-bottom: 100px;border-style:solid;border-color: rgb(0 0 0 / 67%);">
                        					<div class="space40">&nbsp;</div>
                        					<div class="control-group">
                                                <label class="control-label">Họ và tên</label>
                                                <div class="controls">
                                                    <input type="text" name="full_name" class="form-control" placeholder="Nhập họ và tên đầy đủ" required/>
                                                </div><br/>
                                            </div>

                        					<div class="control-group">
                                                <label class="control-label">Tài khoản</label>
                                                <div class="controls">
                                                    <input type="text" name="username" class="form-control" placeholder="Nhập tài khoản" required/>
                                                </div><br/>
                                            </div>
                        					<div class="control-group">
                                                <label class="control-label">Email</label>
                                                <div class="controls">
                                                    <input type="text" name="email" class="form-control" placeholder="expample@gmail.com" />
                                                </div><br/>
                                            </div>
                        					<div class="control-group">
                                                <label class="control-label">Mật khẩu</label>
                                                <div class="controls">
                                                    <input type="password" name="password" class="form-control"  placeholder="**********" autocomplete="off" required/>                                  
                                                </div><br/>
                                            </div>
                        					<div class="control-group">
                                                <label class="control-label">Nhập lại mật khẩu</label>
                                                <div class="controls">
                                                    <input type="password" name="re_password" class="form-control" placeholder="**********" autocomplete="off" required/>                                  
                                                </div><br/>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label">Số điện thoại</label>
                                                <div class="controls">
                                                    <input type="text" name="phone" value="" class="form-control" id="inputPhone" placeholder="Nhập số điện thoại"/><br/>
                                                </div><br/>
                                            </div>
                                            <div class="control-group" style="float: right;">
                                                <div class="controls">
                                                    <button type="submit" class="btn btn-danger">Đăng ký</button>
                                                </div><br/>
                                            </div>
                                            <div class="control-group text-muted">Đã có tài khoản?
                                                <a href="{{route('dangky')}}"><i ></i><u>Đăng nhập</u></a>
                                            </div>
                                           
                                        </div>                                       
                        				<div class="col-sm-3"></div>
                        			</div>
                        		</form>
                            </div>
                        </div> 
                    </div>
                </div>
		    </div> <!-- /.center-content -->
        </div>
    </div>
</main><!-- /.main-part--> 
@endsection