@extends('layout.master')
@section('header_style')
<style>
  .footer_fix_bottom{
    position: fixed;
    bottom: 0px;
    left: 0px;
    right: 0px;
    margin-bottom: 0px;
}
</style>
@endsection
@section('content')
<main class="main section-color-primary">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="top-title">
                    <ul class="breadcrumb">
                        <li class="item"><a href="/"> Trang chủ </a></li>
                        <li class="item"> Đăng nhập </li>
                    </ul>
                    
                </section> <!-- /. content-header --> 
                    <div class="row">
                        <div class="container">
                            <p style="text-align: center;"><h1 class="h-side-title page-title page-title-big text-color-primary">Đăng nhập</h1> </p><br/>
                            <div id="content" style="margin-bottom: 100px;">
                                <form action="{{route('post_dangnhap')}}" method="post" class="beta-form-checkout">
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <div class="row">
                                        <div class="col-sm-3"></div>
                                       
                                        <div class="col-sm-6"  style="margin-bottom: 100px;border-style:solid;border-color: rgb(0 0 0 / 67%);     padding: 20px;">
                                            @if(Session::has('thongbao'))
                                                <div class="alert alert-{{Session::get('thongbao')}}" style="color: red; text-align: center; margin-bottom: 0px;">{{Session::get('thongbao')}}</div>
                                            @endif 
                                            <div class="control-group">
                                                <label class="control-label" for="inputUsername2">Tài khoản</label>
                                                <div class="controls">
                                                    <input type="text" name="username" class="form-control" placeholder="Nhập tài khoản" required/>
                                                </div><br/>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label" for="inputPassword1">Mật khẩu</label>
                                                <div class="controls">
                                                    <input type="password" name="password" class="form-control" placeholder="Nhập mật khẩu" required/>
                                                </div><br/>
                                            </div>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <div class="checkbox">
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="control-group" style="float: right;">
                                                <div class="controls">
                                                    <button type="submit" class="btn btn-danger">Đăng nhập</button>
                                                    <!-- <a href="#"><em>Quên mật khẩu?</em></a> -->
                                                </div>
                                            </div>
                                            <div class="control-group text-muted">Chưa có tài khoản?
                                                <a href="{{route('dangky')}}"><i ></i><u>Đăng ký ngay</u></a>
                                            </div>
                                        </div>
                                        <div class="col-sm-3"></div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection

