@extends('layout.master')
@section('content')
<main class="main section-color-primary">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="top-title">
                    <ul class="breadcrumb">
                        <li class="item"><a href="/"> Trang chủ </a></li>
                        <li class="item"> Đăng ký </li>
                    </ul>
                    <h1 class="h-side-title page-title page-title-big text-color-primary">Thông tin cá nhân</h1> 
                </section> 
                    <div class="row">
                        <div class="container">
		                    <div id="content">
                                <form action="/thong-tin-ca-nhan/save" method="post" class="beta-form-checkout">
                                    {{ csrf_field() }}
                        			<div class="row">
                                        <div class="col-sm-3"></div>
                        				<div class="col-sm-6"  style="margin-bottom: 100px;border-style:solid;border-color: rgb(0 0 0 / 67%);">
                                            <div class="space40">&nbsp;</div>
                                            @if(count($errors)>0)
                                                <div class="alert alert-success">
                                                    @foreach($errors->all() as $err)
                                                        {{$err}}
                                                    @endforeach
                                                </div>
                                            @endif
                                            @if(Session::has('thanhcong'))
                                                <div class="alert alert-success">{{Session::get('thanhcong')}}</div>
                                            @endif
                        					<div class="control-group">
                                                <label class="control-label">Họ và tên</label>
                                                <div class="controls">
                                                    <input type="text" name="full_name" class="form-control" value="{{ $user->full_name }}" placeholder="Nhập họ và tên đầy đủ" required/>
                                                </div><br/>
                                            </div>

                        					<div class="control-group">
                                                <label class="control-label">Email</label>
                                                <div class="controls">
                                                    <input type="text" name="email" class="form-control" value="{{ $user->email }}" placeholder="expample@gmail.com" />
                                                </div><br/>
                                            </div>
                        					
                                            <div class="control-group">
                                                <label class="control-label">Số điện thoại</label>
                                                <div class="controls">
                                                    <input type="text" name="phone" value="{{ $user->phone }}" class="form-control" id="inputPhone" placeholder="Nhập số điện thoại"/><br/>
                                                </div>
                                            </div>
                                            <div class="control-group" >
                                                <div class="controls text-center">
                                                    <button type="submit" class="w-50 btn btn-danger">Cập nhật</button>
                                                </div><br/>
                                            </div>
                                        </div>                                       
                        				<div class="col-sm-3"></div>
                        			</div>
                        		</form>
                            </div>
                        </div> 
                    </div>
                </div>
		    </div> <!-- /.center-content -->
        </div>
    </div>
</main><!-- /.main-part--> 
@endsection