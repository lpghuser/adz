@extends('master')
@section('content')
<main class="main section-color-primary">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <section class="content-header">
                    <h1>
                        <small>Edit</small>
                    </h1>
                <ol class="breadcrumb">
                    <li><a href="/"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li>Edit</li>
                </ol>
            </section>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="col-sm-12">
                            <div class="row">
                            <!-- @if($errors->any())
                                <div class="col-sm-12">
                                    <ul>
                                        @foreach($errors->all() as $error)
                                        <li>{{ $error}}</li>
                                        @endforeach
                                    </ul>
                            @endif
                            <div>
                                <a href="/" class="btn btn-default">Back</a>
                            </div> -->
                                    <form action="{{route('update')}}" method="POST" enctype="multipart/form-data">

                                        {{ csrf_field() }}
                                        <input type="hidden" name="id" value="{{ $data->id }}">
                                        @method('POST')
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">Plost</label>
                                                    <div class="col-sm-7">
                                                        <input name="plost" required value="{{ isset($data['plost']) ? $data['plost'] : old('plost') }}" class="form-control">
                                                    </div>
                                                    @if($errors->has('plost'))
                                                    <div class="error" style="color: red;">{{ $errors->first('plost') }}</div>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">Puller</label>
                                                    <div class="col-sm-7">
                                                        <input type="file" id="puller" class="form-control input_disable"
                                                            name="puller"
                                                            value="chọn file">
                                                        </div>
                                                     @if($errors->has('puller'))
                                                    <div class="error" style="color: red;">{{ $errors->first('puller') }}</div>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">Adress</label>
                                                    <div class="col-sm-7">
                                                        <input name="adress" required value="{{ isset($data['adress']) ? $data['adress'] : old('adress') }}" class="form-control">
                                                    </div>
                                                    @if($errors->has('adress'))
                                                    <div class="error" style="color: red;">{{ $errors->first('adress') }}</div>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">Ward_Id</label>
                                                    <div class="col-sm-7">
                                                        <input name="ward_id" value="{{ isset($data['ward_id']) ? $data['ward_id'] : old('ward_id') }}" class="form-control">
                                                    </div>
                                                    @if($errors->has('ward_id'))
                                                    <div class="error" style="color: red;">{{ $errors->first('ward_id') }}</div>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">Ditrict_Id</label>
                                                    <div class="col-sm-7">
                                                        <input name="district_id" value="{{ isset($data['district_id']) ? $data['district_id'] : old('district_id') }}" class="form-control">
                                                    </div>
                                                    @if($errors->has('district_id'))
                                                    <div class="error" style="color: red;">{{ $errors->first('district_id') }}</div>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">City_Id</label>
                                                    <div class="col-sm-7">
                                                        <input name="city_id" value="{{ isset($data['city_id']) ? $data['city_id'] : old('city_id') }}" class="form-control">
                                                    </div>
                                                    @if($errors->has('city_id'))
                                                    <div class="error" style="color: red;">{{ $errors->first('city_id') }}</div>
                                                    @endif
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <div class="row">
                                                    <label class="col-sm-5 control-label">Is Plain</label>
                                                    <div class="col-sm-7">
                                                    <select class="form-control select2" name="is_plain" required>
                                                            <option value="">----Is Plain ---</option>
                                                            <option {{$data->is_plain==0 ? 'selected' : ''  }} value="0">No</option>
                                                            <option {{$data->is_plain==1 ? 'selected' : ''  }} value="1">Yes</option>
                                                    </select>
                                                    </div>
                                                    </div>
                                                    @if($errors->has('is_plain'))
                                                    <div class="error" style="color: red;">{{ $errors->first('is_plain') }}</div>
                                                    @endif
                                                </div>
                                            </div>
                                            <svg class="barcode"
                                                jsbarcode-format="auto"
                                                jsbarcode-value="product_1"
                                                jsbarcode-textmargin="0"
                                                jsbarcode-fontoptions="bold">
                                            </svg>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <div class="row">
                                                    <input type="submit" class="btn btn-info" value="Save">
                                                    <input type="reset" class="btn btn-warning" value="Reset">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Add Article</button>

        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
            
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add</h4>
                </div>
                <div class="modal-body">
                    <form action="{{ route('store')}}" method="POST" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        @method('POST')
                        <div class="control-group">
                            <label class="control-label">Plost</label>
                            <div class="controls">
                            <input type="text" name="plost" class="form-control" placeholder="Plost" required/> 
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" >Puller</label>
                            <div class="controls">
                            <input type="file" name="puller" class="form-control" placeholder="Puller" required/>                                  
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">Address</label>
                            <div class="controls">
                            <textarea name="adress" cols="40" rows="3" class="form-control" placeholder="Address" required></textarea>                                  
                            </div>
                        </div>  
                        <div class="control-group">
                            <label class="control-label">Ward_Id(Please enter the number)</label>
                            <div class="controls">
                            <input type="text" name="ward_id" class="form-control"  placeholder="Ward_Id" required/>                                  
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">District_Id(Please enter the number)</label>
                            <div class="controls">
                            <input type="text" name="district_id" class="form-control" placeholder="District_Id"  required/>                                  
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">City_Id(Please enter the number)</label>
                            <div class="controls">
                            <input type="text" name="city_id" class="form-control" placeholder="City_Id"  required/>                                  
                            </div>
                        </div>  
                        <div class="control-group">
                            <label class="control-label">Is Plain</label>
                            <div class="controls">
                                <select class="form-control select2" name="is_plain" required>
                                    <option value="">----Is Plain ---</option>
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>                                  
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="controls">
                                <button type="submit" class="btn btn-danger">Add</button>
                                <button type="reset" class="btn btn-success">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            </div>
        </div>
</div>
</div>
</section>  
                            <div class="widget widget-box box-container">
                                <div class="widget-header text-uppercase">
                                    <h3>Bank Payment Details</h3>
                                </div>
                                <div class="widget-content">
                                    IBAN: HR43 2340009 3207462177<br />
                                    SWIFT: PBZGHR2X<br />
                                    Notice: Please enter 'property id #' in Bank transfer notice
                                </div>
                            </div> <!-- /. widget-->   
                        </div><!-- /.center-content -->
                    </div>
                </div>
            </main><!-- /.main-part--> 
@endsection