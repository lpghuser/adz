@extends('master')
@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="top-title">
            <ul class="breadcrumb">
                <li class="item"><a href="/"> Home </a></li>
                <li class="item"> My listings </li>
        </ul>
        <h1 class="h-side-title page-title page-title-big text-color-primary">My listings</h1> 
         </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table class="table table-bordered">
                                <thead class="thead-light">
                                <tr>
                                    <!-- <th scope="col">ID</th> -->
                                    <th scope="col">Plost</th>
                                    <th scope="col">Puller</th>
                                    <th scope="col">Address</th>
                                    <th scope="col">Ward_Id</th>
                                    <th scope="col">District_Id</th>
                                    <th scope="col">City_Id</th>
                                    <th scope="col">Is Plain</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                    @foreach($thuadat as $show => $thua )
                                    <tr>
                                        <!-- <td>{{ $thua->id}}</td> -->
                                        <td>{{ $thua->plost }}</td>
                                        <!-- <td><img src="{{ URL::to('/') }}/puller/{{ $thua->puller }}" class="img-thumbnail" width="75" /></td> -->
                                        <td><div class="openTab"><a class="newTab" data-link="{{ url::to('/') }}/puller/{{ $thua->puller }}" href="#">{{ $thua->puller }}</a></div></td>
                                        <td>{{ $thua->adress }}</td>
                                        <td>{{ $thua->ward_id }}</td>
                                        <td>{{ $thua->district_id }}</td>
                                        <td>{{ $thua->city_id }}</td>
                                        <td>{{ $thua->is_plain }}</td>
                                        <td><a href="{{route('get_edit', $thua->id)}}" class="btn btn-warning btn-xs">Edit </a></td>
                                        <td><a href="{{route('destroy', $thua->id)}}" class="btn btn-danger btn-xs">Delete </a></td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
@section('footer')
    <script>
         $('.openTab').click(function(){
            var a = $(this).find(".newTab").attr('data-link');
            window.open(a, '_blank');
        });
    </script>
    <!-- <srcipt type="text/javacript">
        $(document).ready(function () {
            var table = $()
        });
    </script> -->
@endsection