@extends('master')
@section('content')
<main class="main section-color-primary">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <section class="top-title">
                                <ul class="breadcrumb">
                                    <li class="item"><a href="/"> Home </a></li>
                                    <li class="item"> Article </li>
                                </ul>
                                <h1 class="h-side-title page-title page-title-big text-color-primary">Article</h1> 
                            </section> <!-- /. content-header --> 
                            <div class="widget widget-box box-container">
                                <div class="widget-header text-uppercase">
                                    <h2>Available Packages</h2>
                                </div>
                                
                            </div> <!-- /. widget-AVAILABLE PACKAGES -->   
                            <div class="row">
                            <div class="container">
		<div id="content">
                                    
    	<form action="{{route('post_dat')}}" method="post" class="beta-form-checkout" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">
				<div class="row">
                    <div class="col-sm-3"></div>
                    @if(count($errors)>0)
                        <div class="alert alert-success">
                            @foreach($errors->all() as $err)
                                {{$err}}
                            @endforeach
                        </div>
                    @endif
                    @if(Session::get('thongbao'))
					<div class="alert alert-{{Session::get('slug')}}">{{Session::get('thongbao')}}</div>
				    @endif
                    @if(Session::has('luu'))
                        <div class="alert alert-success">{{Session::get('luu')}}</div>
                    @endif
					<div class="col-sm-6">
						<h4>Arrticle</h4>
						<div class="space40">&nbsp;</div>
						<div class="control-group">
                            <label class="control-label">Plost</label>
                            <div class="controls">
                            <input type="text" name="plost" class="form-control" placeholder="Plost" required/> 
                            </div>
                        </div>

						<div class="control-group">
                            <label class="control-label" >Puller</label>
                            <div class="controls">
                            <input type="file" name="puller" class="form-control" placeholder="Puller" required/>                                  
                            </div>
                        </div>
						<div class="control-group">
                            <label class="control-label">Address</label>
                            <div class="controls">
                            <textarea name="adress" cols="40" rows="3" class="form-control" placeholder="Address" required></textarea>                                  
                            </div>
                        </div>  
						<div class="control-group">
                            <label class="control-label">Ward_Id(Please enter the number)</label>
                            <div class="controls">
                            <input type="text" name="ward_id" class="form-control"  placeholder="Ward_Id" required/>                                  
                            </div>
                        </div>
						<div class="control-group">
                            <label class="control-label">District_Id(Please enter the number)</label>
                            <div class="controls">
                            <input type="text" name="district_id" class="form-control" placeholder="District_Id"  required/>                                  
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label">City_Id(Please enter the number)</label>
                            <div class="controls">
                            <input type="text" name="city_id" class="form-control" placeholder="City_Id"  required/>                                  
                            </div>
                        </div>  
                        <div class="control-group">
                            <label class="control-label">Is Plain</label>
                            <div class="controls">
                                <select class="form-control select2" name="is_plain" required>
                                    <option value="">----Is Plain ---</option>
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                </select>                                  
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="controls">
                            <button type="submit" class="btn btn-danger">Save</button>
                            <button type="reset" class="btn btn-success">Reset</button>
                            </div>
                        </div>
                    </div>
                   
					<div class="col-sm-3"></div>
				</div>
			</form>
		</div> <!-- /.center-content -->
                    </div>
                </div>
            </main><!-- /.main-part--> 
@endsection